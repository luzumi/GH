export const environment = {
  production: false,
  API_KEY: '99e16a77da2c820fb54d68c9ea54f713r',
  apiBaseUrl: 'http://localhost:3000/api'
};
