import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppTitleService {
  title = 'Ground Dropper';
}
